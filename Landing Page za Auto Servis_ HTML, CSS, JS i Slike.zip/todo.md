# Auto Servis Landing Page - Todo Lista

## Faza 1: Planiranje i dizajn landing stranice
- [x] Definirati strukturu stranice (header, hero, usluge, o nama, kontakt, footer)
- [x] Odrediti color palette i tipografiju
- [x] Planirati responsive dizajn
- [x] Definirati potrebne slike

## Faza 2: Pretraživanje i prikupljanje slika
- [x] Pronaći hero sliku (auto servis)
- [x] Pronaći slike za usluge (popravka motora, gume, dijagnostika)
- [x] Pronaći logo ili kreirati placeholder
- [x] Organizovati slike u folder

## Faza 3: Kreiranje HTML strukture
- [x] Kreirati osnovnu HTML strukturu
- [x] Dodati semantic HTML elemente
- [x] Uključiti meta tagove za SEO
- [x] Dodati responsive viewport meta tag

## Faza 4: Kreiranje CSS stilova
- [x] Kreirati osnovne stilove i reset
- [x] Implementirati responsive grid sistem
- [x] Stilizovati header i navigaciju
- [x] Stilizovati hero sekciju
- [x] Stilizovati sekciju usluga
- [x] Stilizovati kontakt sekciju
- [x] Dodati hover efekte i animacije

## Faza 5: Kreiranje JavaScript funkcionalnosti
- [x] Implementirati smooth scrolling
- [x] Kreirati mobile menu toggle
- [x] Dodati form validaciju
- [x] Implementirati scroll animacije

## Faza 6: Testiranje i finalizacija
- [x] Testirati u browseru
- [x] Provjeriti responsive dizajn
- [x] Optimizovati performanse

## Faza 7: Dostavljanje datoteka
- [x] Organizovati sve datoteke
- [x] Poslati korisniku odvojene datoteke

