# ProAuto Servis - Landing Page

Profesionalna landing stranica za auto servis kreirana sa HTML, CSS i JavaScript.

## Struktura datoteka

```
auto_servis_landing_page/
├── index.html          # Glavna HTML datoteka
├── styles.css          # CSS stilovi
├── script.js           # JavaScript funkcionalnosti
├── README.md           # Ova datoteka
└── images/             # Folder sa slikama
    ├── hero_background.jpg    # Hero pozadinska slika
    ├── engine_repair.jpg      # Slika za popravku motora
    ├── tire_change.jpg        # Slika za mijenjanje guma
    └── car_diagnostic.jpg     # Slika za dijagnostiku
```

## Funkcionalnosti

### HTML (index.html)
- Semantic HTML5 struktura
- SEO optimizovane meta tagove
- Responsive viewport konfiguracija
- Accessibility friendly markup

### CSS (styles.css)
- Responsive dizajn (mobile-first)
- CSS Grid i Flexbox layout
- CSS varijable za lakše održavanje
- Smooth animacije i hover efekti
- Modern glassmorphism efekti

### JavaScript (script.js)
- Mobile hamburger menu
- Smooth scrolling navigacija
- Form validacija sa error handling
- Scroll animacije (Intersection Observer)
- Scroll-to-top button
- Counter animacije
- Performance optimizacije

## Responsive Breakpoints

- **Mobile**: 320px - 768px
- **Tablet**: 768px - 1024px  
- **Desktop**: 1024px+

## Sekcije stranice

1. **Header/Navigation** - Sticky header sa smooth scroll linkovima
2. **Hero** - Pozadinska slika sa call-to-action buttonima i statistikama
3. **Usluge** - Grid layout sa karticama usluga
4. **O nama** - Informacije o firmi sa feature listom
5. **Kontakt** - Kontakt forma sa validacijom i kontakt informacije
6. **Footer** - Linkovi i dodatne informacije

## Kako pokrenuti

1. Otvorite `index.html` u web browseru
2. Ili postavite datoteke na web server
3. Sve datoteke moraju biti u istom direktoriju

## Customizacija

### Mijenjanje boja
Uredite CSS varijable u `:root` sekciji `styles.css` datoteke:

```css
:root {
    --primary-color: #1a365d;    /* Glavna boja */
    --secondary-color: #e53e3e;  /* Akcent boja */
    --neutral-color: #f7fafc;    /* Pozadinska boja */
}
```

### Mijenjanje sadržaja
- Uredite tekst direktno u `index.html`
- Zamijenite slike u `images/` folderu
- Prilagodite kontakt informacije

### Dodavanje novih sekcija
1. Dodajte HTML strukturu u `index.html`
2. Dodajte CSS stilove u `styles.css`
3. Dodajte JavaScript funkcionalnosti u `script.js` ako je potrebno

## Browser podrška

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Performance optimizacije

- Lazy loading za slike
- Debounced scroll eventi
- CSS animacije umjesto JavaScript
- Optimizovane slike
- Minified kod (production ready)

## Kontakt

Za pitanja ili customizacije kontaktirajte developera.

