# Auto Servis Landing Page - Dizajn Koncept

## Vizuelni Stil
- **Tema**: Profesionalna, pouzdana, moderna
- **Mood**: Tehnička ekspertiza, kvalitet, povjerenje
- **Ton**: Profesionalan ali pristupačan

## Color Palette
- **Primarna**: #1a365d (tamno plava - pouzdanost)
- **Sekundarna**: #e53e3e (crvena - akcent, hitnost)
- **Neutralna**: #f7fafc (svijetlo siva - pozadina)
- **Tekst**: #2d3748 (tamno siva)
- **Bijela**: #ffffff

## Tipografija
- **Headings**: 'Roboto', sans-serif (bold, modern)
- **Body**: 'Open Sans', sans-serif (readable, professional)
- **Sizes**: H1: 3rem, H2: 2.5rem, H3: 2rem, Body: 1rem

## Layout Struktura

### 1. Header/Navigation
- Logo lijevo
- Navigacijski meni desno
- Sticky header
- Mobile hamburger menu

### 2. Hero Sekcija
- Velika pozadinska slika (auto servis)
- Overlay sa glavnim naslovom
- CTA button
- Kratki opis usluga

### 3. Usluge Sekcija
- Grid layout (3 kolone)
- Ikone ili slike za svaku uslugu
- Kratki opisi
- Hover efekti

### 4. O Nama Sekcija
- Tekst lijevo, slika desno
- Iskustvo i kvalifikacije
- Brojevi/statistike

### 5. Kontakt Sekcija
- Kontakt forma lijevo
- Informacije desno
- Mapa (placeholder)

### 6. Footer
- Kontakt informacije
- Radno vrijeme
- Social media linkovi

## Interaktivni Elementi
- Smooth scrolling
- Hover animacije na kartice usluga
- Form validacija
- Mobile responsive menu
- Scroll-triggered animacije

## Responsive Breakpoints
- Mobile: 320px - 768px
- Tablet: 768px - 1024px
- Desktop: 1024px+

## Potrebne Slike
1. Hero pozadina - auto servis radionica
2. Usluga 1 - popravka motora
3. Usluga 2 - mijenjanje guma
4. Usluga 3 - dijagnostika
5. O nama - tim ili radionica
6. Logo - auto servis logo

